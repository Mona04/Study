/* eslint-disable */
declare module 'markdown-wasm/dist/markdown.node.js' {
  export const parse: typeof import('markdown-wasm').parse
}
