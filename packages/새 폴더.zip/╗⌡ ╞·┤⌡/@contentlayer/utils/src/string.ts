export const lowercaseFirstChar = (str: string) => str.charAt(0).toLowerCase() + str.slice(1)
export const uppercaseFirstChar = (str: string) => str.charAt(0).toUpperCase() + str.slice(1)
