declare module 'eval'
