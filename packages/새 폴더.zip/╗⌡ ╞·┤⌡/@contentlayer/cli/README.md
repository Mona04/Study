# @contentlayer/cli

Currently (in order to keep the build setup minimal) this CLI package only contains the CLI source but cannot be run directly. Instead it needs to be built & run via `packages/contentlayer`.
